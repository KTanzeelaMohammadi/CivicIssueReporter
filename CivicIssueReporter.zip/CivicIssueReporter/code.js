// ===== Civic Issue Reporter: made for your design =====// RUN ONCE to create the table, then delete these lines
createRecord("issues", {category: "Test", area: "Test", desc: "Test", votes: 0, status: "Resolved", date: "Setup"}, function() {
  console.log("Table created");
});
var HOME_SCREEN = "homeScreen";
var REPORT_SCREEN = "screen2";      // change this if you rename the screen
var LIST_SCREEN = "listScreen";
var ADMIN_PIN = "1234";             // demo PIN, change it

var categories = ["Pothole", "Garbage", "Streetlight", "Water Leak", "Drainage", "Other"];
var iconFor = {
  "Pothole": "assets/pothole.png",
  "Garbage": "garbage.png",
  "Streetlight": "streetlight.png",
  "Water Leak": "waterleak.png",
  "Drainage": "drainage.png",
  "Other": "other.png"
};
var allIssues = [];

// ---------- SETUP ----------
setProperty("categoryDropdown", "options", categories);
setProperty("filterDropdown", "options", ["All"].concat(categories));
setProperty("catIcon", "image", iconFor["Pothole"]);
setText("msgLabel", "");

// ---------- HOME: STATS ----------
function loadStats() {
  readRecords("issues", {}, function(records) {
    var resolved = 0;
    var counts = {};
    for (var i = 0; i < records.length; i++) {
      if (records[i].status === "Resolved") { resolved++; }
      counts[records[i].category] = (counts[records[i].category] || 0) + 1;
    }
    var top = "-";
    var max = 0;
    for (var c in counts) {
      if (counts[c] > max) { max = counts[c]; top = c; }
    }
    setText("statsLabel", "Reported : " + records.length + "\nResolved : " + resolved + "\nMost common : " + top);
  });
}
loadStats();

// ---------- NAVIGATION ----------
onEvent("reportBtn", "click", function() {
  setText("msgLabel", "");
  setScreen(REPORT_SCREEN);
});
onEvent("viewBtn", "click", function() {
  setScreen(LIST_SCREEN);
  loadIssues();
});
onEvent("backBtn1", "click", function() {
  setText("msgLabel", "");
  setScreen(HOME_SCREEN);
  loadStats();
});
onEvent("backBtn2", "click", function() {
  setScreen(HOME_SCREEN);
  loadStats();
});

// ---------- REPORT SCREEN ----------
onEvent("categoryDropdown", "change", function() {
  setProperty("catIcon", "image", iconFor[getText("categoryDropdown")]);
});

function showMsg(text, color) {
  setText("msgLabel", text);
  setProperty("msgLabel", "text-color", color);
}

onEvent("submitBtn", "click", function() {
  var area = getText("areaInput").trim();
  var desc = getText("descInput").trim();
  if (area === "" || desc === "") {
    showMsg("Please fill in the area and description.", "red");
    return;
  }
  createRecord("issues", {
    category: getText("categoryDropdown"),
    area: area.substring(0, 40),
    desc: desc.substring(0, 100),
    votes: 1,
    status: "Open",
    date: new Date().toDateString()
  }, function() {
    showMsg("Reported! Thank you.", "green");
    setText("areaInput", "");
    setText("descInput", "");
  });
});

// ---------- LIST SCREEN ----------
function loadIssues() {
  setText("issuesLabel", "Loading...");
  readRecords("issues", {}, function(records) {
    var filter = getText("filterDropdown");
    allIssues = [];
    for (var i = 0; i < records.length; i++) {
      if (filter === "All" || records[i].category === filter) {
        appendItem(allIssues, records[i]);
      }
    }
    // most voted first
    allIssues.sort(function(a, b) { return b.votes - a.votes; });

    var text = "";
    var ids = [];
    for (var j = 0; j < allIssues.length; j++) {
      var r = allIssues[j];
      appendItem(ids, String(r.id));          // every issue can be selected
      if (j < 5) {                            // show only the top 5 so text fits
        var mark = r.status === "Resolved" ? "[DONE]" : "[OPEN]";
        text += mark + " #" + r.id + " " + r.category + " - " + r.area + "\n";
        text += r.desc + "\n" + r.votes + " votes | " + r.date + "\n\n";
      }
    }
    if (allIssues.length > 5) { text += "...and " + (allIssues.length - 5) + " more"; }
    if (text === "") { text = "No issues found."; }
    setText("issuesLabel", text);
    setProperty("issueDropdown", "options", ids);
  });
}
onEvent("filterDropdown", "change", loadIssues);

function findSelected() {
  var id = getText("issueDropdown");
  for (var i = 0; i < allIssues.length; i++) {
    if (String(allIssues[i].id) === id) { return allIssues[i]; }
  }
  return null;
}

onEvent("voteBtn", "click", function() {
  var issue = findSelected();
  if (issue) {
    issue.votes++;
    updateRecord("issues", issue, function() { loadIssues(); });
  }
});

onEvent("resolveBtn", "click", function() {
  var issue = findSelected();
  if (issue && getText("pinInput") === ADMIN_PIN) {
    issue.status = "Resolved";
    updateRecord("issues", issue, function() {
      setText("pinInput", "");
      loadIssues();
    });
  } else {
    setText("pinInput", "");
    setProperty("pinInput", "placeholder", "Wrong PIN");
  }
});